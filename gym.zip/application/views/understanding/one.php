<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php echo base_url(); ?>
    <h1>Hello Dipro, Welcome to codeigniter</h1>
  </body>
</html>
